package com.employee.services;

import java.util.List;

import com.employee.module.Employee;

public interface EmployeeServices {

	public Employee saveEmployee(Employee employee);
	
	public List<Employee> getAllEmployees();
	
	public Employee getEmployeeById(int empId);
	
	public void deleteemployee(int empId);
	
	public Employee updateEmployee(Employee employee);
}
