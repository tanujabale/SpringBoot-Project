package com.employee.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.dao.EmployeeRepo;
import com.employee.module.Employee;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeRepo empRepo;
	
	@GetMapping("/getAllEmployees")
	public ResponseEntity<List<Employee>> getAll(){
		List<Employee> list= empRepo.findAll();
		if(list.size()<=0) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
		return ResponseEntity.of(Optional.of(list));	
	}
	
	@GetMapping("/getEmployee/{empId}")
	public ResponseEntity<Employee> findStudent(@PathVariable int empId) {
	    try {
	        Optional<Employee> emp = empRepo.findById(empId);
	        if (emp.isPresent()) {
	            return ResponseEntity.ok(emp.get()); 
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                                 .body(null);
	        }
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                             .body(null); 
	    }
	}
	
	@PostMapping("/addEmployee")
	public ResponseEntity<Employee> save(@RequestBody Employee emp) {
	    try {
	        Employee saveEmployee = empRepo.save(emp);
	        return ResponseEntity.status(HttpStatus.CREATED).body(saveEmployee); 
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null); 
	    }
	}
	
	
	@DeleteMapping("/deleteEmloyee/{empId}")
	public ResponseEntity<String> delete(@PathVariable int empId) {
	    try {
	        Optional<Employee> st = empRepo.findById(empId);
	        if (st.isPresent()) {
	            empRepo.delete(st.get());
	            return ResponseEntity.ok("Deleted Employee id: " + empId); 
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee not found with id: " + empId); 
	        }
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while deleting the student"); 
	    }
	}

	@PutMapping("/updateemployee")
	public ResponseEntity<Employee> update(@RequestBody Employee emp) {
	    try {
	        if (empRepo.existsById(emp.getEmpId())) { 
	            Employee updatedEmployee = empRepo.save(emp);
	            return ResponseEntity.ok(updatedEmployee); 
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); 
	        }
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null); 
	    }
	}
	
}
